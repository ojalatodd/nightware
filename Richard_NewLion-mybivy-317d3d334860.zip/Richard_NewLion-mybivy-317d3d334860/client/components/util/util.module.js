'use strict';

angular.module('mybivyApp.util', []);
