'use strict';

class NavbarController {
  //start-non-standard
  menu = [
  //{
    // 'title': 'Home'
    // , 'state': 'main'
  //}
  // , {
  //   'title': 'Create'
  //   , 'state': 'create'
  // }
  //,
    {
    'title': 'View Data'
    , 'state': 'read'
  }
  , {
    'title': 'Manage Users'
    , 'state': 'manageUsers'
  }
  ];

  isCollapsed = true;
  //end-non-standard

  toggle() {

    if ($('#navbar-main').hasClass('collapse')) {
      $('#navbar-main').removeClass('collapse');
    } else {
      $('#navbar-main').addClass('collapse');
    }
  }

  constructor(Auth) {
    this.isLoggedIn = Auth.isLoggedIn;
    this.isAdmin = Auth.isAdmin;
    this.getCurrentUser = Auth.getCurrentUser;
  }
}

angular.module('mybivyApp')
  .controller('NavbarController', NavbarController);
