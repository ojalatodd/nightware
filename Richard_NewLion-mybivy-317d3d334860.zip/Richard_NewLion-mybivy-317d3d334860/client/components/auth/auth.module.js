'use strict';

angular.module('mybivyApp.auth', [
  'mybivyApp.constants',
  'mybivyApp.util',
  'ngCookies',
  'ui.router'
])
  .config(function($httpProvider) {
    $httpProvider.interceptors.push('authInterceptor');
  });
