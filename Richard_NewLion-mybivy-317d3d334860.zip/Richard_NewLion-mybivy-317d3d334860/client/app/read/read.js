'use strict';

angular.module('mybivyApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('read', {
        url: '/read',
        params: {
          userCode: ''
        },
        templateUrl: 'app/read/read.html',
        controller: 'ReadCtrl',
        controllerAs: 'read',
        authenticate: true
      })
    // .state('main', {
    //     url: '/',
    //     templateUrl: 'app/read/read.html',
    //     controller: 'ReadCtrl',
    //     controllerAs: 'read',
    //     authenticate: true
    //   });
  });
