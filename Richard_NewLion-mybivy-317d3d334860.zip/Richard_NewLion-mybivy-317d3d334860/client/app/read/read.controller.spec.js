'use strict';

describe('Controller: ReadCtrl', function () {

  // load the controller's module
  beforeEach(module('mybivyApp'));

  var ReadCtrl, scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    ReadCtrl = $controller('ReadCtrl', {
      $scope: scope
    });
  }));

  it('should ...', function () {
    expect(1).toEqual(1);
  });
});
