'use strict';

angular.module('mybivyApp')
  .controller('ReadCtrl', readController);

function readController($log, $stateParams, $filter, $http) {
  var vm = this;

  // register exported functions
  vm.fetchData = fetchData;
  vm.changeDateFrom = changeDateFrom;

  // declare and initialize variables
  vm.duration = 1;
  vm.startTime = 0;

  vm.dateFrom = new Date();
  vm.dateFrom.setHours(0, 0, 0, 0);// zero out time component
  vm.dateFrom.setHours(-24);// set to previous day
  vm.dateFrom.setHours(vm.startTime);// apply start time offset
  vm.dateTo = new Date(vm.dateFrom.getTime());
  vm.dateTo.setHours(vm.duration);// dateTo = dateFrom + duration

  vm.selectedUserCode;
  vm.studyUsers = [];
  vm.stressData = [];
  vm.interventionData = [];
  vm.stressChartPoints = [];
  vm.chartData = [{},{},{}];
  // each series on the chart needs to be placed into a specific index to avoid having the asynchronous
  // callback functions place multiple series into the chart when the user spams some action that triggers
  // a query.  In order to do this, those indexes must exist, so I initialize chartData with 3 empy objects here.
  vm.interventionChartPoints = [];

  if ($stateParams.userCode !== '') {
    vm.selectedUserCode = $stateParams.userCode;
  }

  fetchData();

  vm.chartConfig = {
    visible: true, // default: true
    extended: false, // default: false
    disabled: false, // default: false
    refreshDataOnly: true, // default: true
    deepWatchOptions: true, // default: true
    deepWatchData: true, // default: true
    deepWatchDataDepth: 2, // default: 2
    debounce: 10 // default: 10
  };

  vm.chartOptions = {
    chart: {
      type: 'lineChart',
      height: 450,
      margin: {
        top: 20,
        right: 20,
        bottom: 40,
        left: 55
      },
      x: function(d) { 
        if (angular.isDefined(d) && angular.isDefined(d.x)) {
          return d.x;
        } else {
          return null;
        }
      },
      y: function(d) { 
        if (angular.isDefined(d) && angular.isDefined(d.y)) {
          return d.y;
        } else {
          return null;
        }
      },
      useInteractiveGuideline: true,
      dispatch: {
        stateChange: function (e) {
          console.log("stateChange");
        },
        changeState: function (e) {
          console.log("changeState");
        },
        tooltipShow: function (e) {
          console.log("tooltipShow");
        },
        tooltipHide: function (e) {
          console.log("tooltipHide");
        }
      },
      xAxis: {
        axisLabel: 'Time',
        tickFormat: function (d) {
          return d3.time.format("%X")(new Date(d));
        }
      },
      yAxis: {
        axisLabel: 'Level',
        tickFormat: function (d) {
          return d3.format('.02f')(d);
        },
        axisLabelDistance: -10
      },
      callback: function (chart) {
        // console.log("!!! lineChart callback !!!");
      }
    },
    title: {
      enable: true,
      text: 'Stress and Intervention Data'
    }
  };

  function fetchData() {
    vm.stressData = [];
    vm.chartData = [];
    vm.interventionData = [];
    vm.stressChartPoints = [];
    vm.interventionChartPoints = [];

    vm.dateFrom.setHours(0, 0, 0, 0);// zero out time component
    vm.dateFrom.setHours(vm.startTime);// add startTime 
    vm.dateTo = new Date(vm.dateFrom.getTime());
    vm.dateTo.setHours(vm.startTime + vm.duration);

    $http.get('/api/studyUsers').then(function (response) {
      // TODO?: optionally query for only active users?

      vm.studyUsers = response.data;

      var dateURL = '/date/' + vm.dateFrom.getTime() + '/' + vm.dateTo.getTime();

      if (!angular.isDefined(vm.selectedUserCode) || vm.selectedUserCode === '') {
        if (angular.isDefined(vm.studyUsers[0]) && angular.isDefined(vm.studyUsers[0].userCode)) {
          vm.selectedUserCode = vm.studyUsers[0].userCode;
        } else {
          // prompt them to select a user?
          return;
        }
      }

      var userURL = '/user/' + vm.selectedUserCode;

      $http.get('/api/stressData' + userURL + dateURL).then(function (response) {
        vm.stressData = [];
        vm.stressChartPoints = [];
        if (angular.isDefined(response.data[0]) && angular.isDefined(response.data[0].userCode)) {
          vm.stressData[response.data[0].userCode] = response.data;
          populateChartStressData(response.data[0].userCode, vm.stressData[response.data[0].userCode]);
        }
      });

      $http.get('/api/interventionData' + userURL + dateURL).then(function (response) {
        vm.interventionData = [];
        vm.interventionChartPoints = [];
        if (angular.isDefined(response.data[0]) && angular.isDefined(response.data[0].userCode)) {
          vm.interventionData[response.data[0].userCode] = response.data;
          populateChartInterventionData(response.data[0].userCode, vm.interventionData[response.data[0].userCode]);
        }
      });

    });
  }

  function populateChartStressData(userCode, inputArray) {
    var stressChartPoints = [];
    var stressActiveChartPoints = [];

    // check to make sure the returning query matches the search terms defined by the user,
    // because some of the inputs trigger a query on change, it isn't difficult to trigger a query,
    // then change the search parameters before that query finishes.

    // should consider setting something up to stop users from generating so many requests.

    if (userCode != vm.selectedUserCode) {
      return;
    }

    var matchingUser = findUserByUserCode(userCode);

    if (angular.isDefined(inputArray[0]) && angular.isDefined(inputArray[0].timestamp)) {
      var timestamp = new Date(inputArray[0].timestamp);
      if (vm.dateFrom.getTime() > timestamp.getTime() || vm.dateTo.getTime() < timestamp.getTime()) {
        return;
      }
    }


    for (var i = 0; i < inputArray.length; i++) {

      if (angular.isDefined(inputArray[i]) && angular.isDefined(inputArray[i].timestamp)) {
        stressChartPoints.push(
          {
            x: new Date(inputArray[i].timestamp)
            , y: inputArray[i].stressLevel
          }
        );

        if (angular.isDefined(inputArray[i].stressActive) && inputArray[i].stressActive == true) {
          stressActiveChartPoints.push({
            x: new Date(inputArray[i].timestamp)
            , y: inputArray[i].stressLevel
          });
        } else {
          stressActiveChartPoints.push({
            x: new Date(inputArray[i].timestamp)
            , y: null
          });
        }

      }
    }

    vm.chartData[0] = {
      values: stressActiveChartPoints
      , key: 'Stress Active'
      , area: true
      , color: '#FFBF87'
    };

    // vm.chartData['stress'] = {
    vm.chartData[1] = {
      values: stressChartPoints
      , key: 'Stress Level'
      , color: '#FF7F0E'
    };
  }

  function populateChartInterventionData(userCode, inputArray) {
    var interventionChartPoints = [];
    var interventionActiveChartPoints = [];

    // check to make sure the returning query matches the search terms defined by the user,
    // because some of the inputs trigger a query on change, it isn't difficult to trigger a query,
    // then change the search parameters before that query finishes.

    // should consider setting something up to stop users from generating so many requests.

    if (userCode != vm.selectedUserCode) {
      return;
    }

    var matchingUser = findUserByUserCode(userCode);

    if (angular.isDefined(inputArray[0]) && angular.isDefined(inputArray[0].timestamp)) {
      var timestamp = new Date(inputArray[0].timestamp);
      if (vm.dateFrom.getTime() > timestamp.getTime() || vm.dateTo.getTime() < timestamp.getTime()) {
        return;
      }
    }

    for (var i = 0; i < inputArray.length; i++) {

      if (angular.isDefined(inputArray[i].interventionActive) && inputArray[i].interventionActive == true) {
        interventionActiveChartPoints.push({
          x: new Date(inputArray[i].timestamp)
          // , y: inputArray[i].interventionLevel
          , y: 40
        });
      } else {
        interventionActiveChartPoints.push({
          x: new Date(inputArray[i].timestamp)
          , y: null
        });
      }

    }

    // vm.chartData[3] = {
    //   values: interventionChartPoints
    //   , key: 'Intervention Level'
    //   , color:'#7777ff'
    // };

    vm.chartData[2] = {
      values: interventionActiveChartPoints
      , key: 'Intervention Active'
      , area: true
      , color: '#BBBBFF'
    };

  }

  function findUserByUserCode(userCode) {
    var user = {};
    for (var i = 0; i < vm.studyUsers.length; i++) {
      if (userCode == vm.studyUsers[i].userCode) {
        user = vm.studyUsers[i];
        break;
      }
    }
    if (user === {}) {
      $log.error('no user found for userCode: ' + userCode);
    }
    return user;
  }

  vm.valuationDatePickerOpen = function ($event) {
    if ($event) {
      $event.preventDefault();
      $event.stopPropagation();
    }
    this.valuationDatePickerIsOpen = true;
  };

  function changeDateFrom(changeBy) {
    vm.dateFrom.setDate(vm.dateFrom.getDate() + changeBy);
    fetchData();
  }

}
