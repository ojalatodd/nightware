'use strict';

angular.module('mybivyApp', [
  'mybivyApp.auth',
  'mybivyApp.admin',
  'mybivyApp.constants',
  'ngCookies',
  'ngResource',
  'ngSanitize',
  'ui.router',
  'ui.bootstrap',
  'validation.match',
  'nvd3',
  'ui.bootstrap.datetimepicker'
])
  .config(function($urlRouterProvider, $locationProvider) {
    $urlRouterProvider
      .otherwise('/login');

    $locationProvider.html5Mode(true);
  });
