'use strict';

//angular.module('mybivyApp')
//  .config(function ($stateProvider) {
//    $stateProvider
//      .state('create', {
//        url: '/create',
//        templateUrl: 'app/create/create.html',
//        controller: 'CreateCtrl',
//        controllerAs: 'create'
//      });
//  });
