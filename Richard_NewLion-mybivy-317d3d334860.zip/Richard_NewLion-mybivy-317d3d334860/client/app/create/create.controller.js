'use strict';

angular.module('mybivyApp')
  .controller('CreateCtrl', createController);

function createController($log, $scope, $http) {

  this.addStressData = addStressData;
  this.addInterventionData = addInterventionData;
  this.addStudyUser = addStudyUser;
  
  this.newStressData = {};
  this.interventionTimestamp;
  this.stressTimestamp;
  this.interventionTimestampMinutes;
  this.stressTimestampMinutes;
  this.newInterventionData = {};
  this.newStudyUser = {};

  function addStressData() {

    this.newStressData.timestamp = new Date(this.stressTimestamp);
    this.newStressData.timestamp.setMinutes(this.stressTimestampMinutes);

    if (this.newStressData !== {}) {
      $http.post('/api/stressData', this.newStressData);
    }

  }

  function addInterventionData() {
    
    this.newInterventionData.timestamp = new Date(this.interventionTimestamp);
    this.newInterventionData.timestamp.setMinutes(this.interventionTimestampMinutes);

    if (this.newInterventionData !== {}) {
      $http.post('/api/interventionData', this.newInterventionData);
    }

  }

  function addStudyUser() {
    
    if (this.newStudyUser !== {}) {
      $http.post('/api/studyUsers', this.newStudyUser);
    }

  }

}