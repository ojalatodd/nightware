'use strict';

angular.module('mybivyApp')
  .config(function ($stateProvider) {
    $stateProvider
      .state('manageUsers', {
        url: '/manageUsers',
        templateUrl: 'app/manageUsers/manageUsers.html',
        controller: 'ManageUsersCtrl',
        controllerAs: 'users',
        authenticate: true
      });
  });
