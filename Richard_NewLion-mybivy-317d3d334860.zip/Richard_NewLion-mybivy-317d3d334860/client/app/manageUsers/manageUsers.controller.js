'use strict';

angular.module('mybivyApp')
  .controller('ManageUsersCtrl', manageUsersController);

function manageUsersController($compile, $log, $scope, $state, $http) {
  var vm = this;

  vm.addUser = addUser;
  vm.editUser = editUser;
  vm.viewUserData = viewUserData;
  vm.clearSelectedUser = clearSelectedUser;
  vm.saveUser = saveUser;

  vm.users = [];
  vm.selectedUser = {};

  $http.get('/api/studyUsers').then(function(response) {
  	vm.users = response.data;
  });

  function addUser() {
    $http.post('/api/studyUsers', {}).then(
      function(response) {
        editUser(response.data);
        vm.users.push(vm.selectedUser);
      }
    );
  }

  function editUser(user) {
    vm.selectedUser = angular.copy(user);
  }

  function saveUser(index) {
    vm.users[index] = angular.copy(vm.selectedUser);
    if (vm.selectedUser._id == 0) {
      $http.post('/api/studyUsers', this.newStudyUser);
    } else {
      $http.put('/api/studyUsers/' + vm.users[index]._id, vm.users[index]).then(function(response) {
      });
    }
    clearSelectedUser();
  }

  function clearSelectedUser() {
    vm.selectedUser = {};
  }

  function viewUserData(user) {
    // send to read page with users id as a parameter
    if (user) {
      $state.go('read', { userCode: user.userCode });
    }
  }

}