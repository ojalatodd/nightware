'use strict';

angular.module('mybivyApp.admin', [
  'mybivyApp.auth',
  'ui.router'
]);
