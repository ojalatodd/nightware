/**
 * StudyUsers model events
 */

'use strict';

import {EventEmitter} from 'events';
var StudyUsers = require('./studyUsers.model');
var StudyUsersEvents = new EventEmitter();

// Set max event listeners (0 == unlimited)
StudyUsersEvents.setMaxListeners(0);

// Model events
var events = {
  'save': 'save',
  'remove': 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  StudyUsers.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function(doc) {
    StudyUsersEvents.emit(event + ':' + doc._id, doc);
    StudyUsersEvents.emit(event, doc);
  }
}

export default StudyUsersEvents;
