'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var studyUsersCtrlStub = {
  index: 'studyUsersCtrl.index',
  show: 'studyUsersCtrl.show',
  create: 'studyUsersCtrl.create',
  update: 'studyUsersCtrl.update',
  destroy: 'studyUsersCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var studyUsersIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './studyUsers.controller': studyUsersCtrlStub
});

describe('StudyUsers API Router:', function() {

  it('should return an express router instance', function() {
    studyUsersIndex.should.equal(routerStub);
  });

  describe('GET /api/studyUsers', function() {

    it('should route to studyUsers.controller.index', function() {
      routerStub.get
        .withArgs('/', 'studyUsersCtrl.index')
        .should.have.been.calledOnce;
    });

  });

  describe('GET /api/studyUsers/:id', function() {

    it('should route to studyUsers.controller.show', function() {
      routerStub.get
        .withArgs('/:id', 'studyUsersCtrl.show')
        .should.have.been.calledOnce;
    });

  });

  describe('POST /api/studyUsers', function() {

    it('should route to studyUsers.controller.create', function() {
      routerStub.post
        .withArgs('/', 'studyUsersCtrl.create')
        .should.have.been.calledOnce;
    });

  });

  describe('PUT /api/studyUsers/:id', function() {

    it('should route to studyUsers.controller.update', function() {
      routerStub.put
        .withArgs('/:id', 'studyUsersCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('PATCH /api/studyUsers/:id', function() {

    it('should route to studyUsers.controller.update', function() {
      routerStub.patch
        .withArgs('/:id', 'studyUsersCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('DELETE /api/studyUsers/:id', function() {

    it('should route to studyUsers.controller.destroy', function() {
      routerStub.delete
        .withArgs('/:id', 'studyUsersCtrl.destroy')
        .should.have.been.calledOnce;
    });

  });

});
