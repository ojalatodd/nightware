'use strict';

var app = require('../..');
import request from 'supertest';

var newStudyUsers;

describe('StudyUsers API:', function() {

  describe('GET /api/studyUsers', function() {
    var studyUserss;

    beforeEach(function(done) {
      request(app)
        .get('/api/studyUsers')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          studyUserss = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      studyUserss.should.be.instanceOf(Array);
    });

  });

  describe('POST /api/studyUsers', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/studyUsers')
        .send({
          name: 'New StudyUsers',
          info: 'This is the brand new studyUsers!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newStudyUsers = res.body;
          done();
        });
    });

    it('should respond with the newly created studyUsers', function() {
      newStudyUsers.name.should.equal('New StudyUsers');
      newStudyUsers.info.should.equal('This is the brand new studyUsers!!!');
    });

  });

  describe('GET /api/studyUsers/:id', function() {
    var studyUsers;

    beforeEach(function(done) {
      request(app)
        .get('/api/studyUsers/' + newStudyUsers._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          studyUsers = res.body;
          done();
        });
    });

    afterEach(function() {
      studyUsers = {};
    });

    it('should respond with the requested studyUsers', function() {
      studyUsers.name.should.equal('New StudyUsers');
      studyUsers.info.should.equal('This is the brand new studyUsers!!!');
    });

  });

  describe('PUT /api/studyUsers/:id', function() {
    var updatedStudyUsers;

    beforeEach(function(done) {
      request(app)
        .put('/api/studyUsers/' + newStudyUsers._id)
        .send({
          name: 'Updated StudyUsers',
          info: 'This is the updated studyUsers!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedStudyUsers = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedStudyUsers = {};
    });

    it('should respond with the updated studyUsers', function() {
      updatedStudyUsers.name.should.equal('Updated StudyUsers');
      updatedStudyUsers.info.should.equal('This is the updated studyUsers!!!');
    });

  });

  describe('DELETE /api/studyUsers/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/studyUsers/' + newStudyUsers._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when studyUsers does not exist', function(done) {
      request(app)
        .delete('/api/studyUsers/' + newStudyUsers._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
