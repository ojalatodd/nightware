/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/studyUsers              ->  index
 * POST    /api/studyUsers              ->  create
 * GET     /api/studyUsers/:id          ->  show
 * GET     /api/studyUsers/userCode/:userCode   ->  check
 * PUT     /api/studyUsers/:id          ->  update
 * DELETE  /api/studyUsers/:id          ->  destroy
 */

'use strict';

import _ from 'lodash';
import StudyUsers from './studyUsers.model';

function respondWithResult(res, statusCode) {
  statusCode = statusCode || 200;
  return function(entity) {
    if (entity) {
      res.status(statusCode).json(entity);
    }
  };
}

function respondWithFound(res, statusCode) {
  statusCode = statusCode || 200;
  return function(entity) {
    if (entity) {
      if (entity.active === true) {
        if (typeof(entity.controlGroup) !== 'undefined') {
          res.status(statusCode).json({
            "success":"Found an active user matching the provided code.",
            "controlGroup":entity.controlGroup
          });
        } else {
          res.status(statusCode).json({
            "success":"Found an active user matching the provided code."
          });
        }
      } else {
        if (typeof(entity.controlGroup) !== 'undefined') {
          res.status(statusCode).json({
            "error":"Found a matching user, but they are listed as inactive.",
            "controlGroup":entity.controlGroup
          });
        } else {
          res.status(statusCode).json({
            "error":"Found a matching user, but they are listed as inactive."
          });
        }
      }
    }
  };
}

function handleUserCodeNotFound(res) {
  return function(entity) {
    if (!entity) {
      res.status(403).json({
        "error":"No user found matching this code, please make sure you entered it correctly."
      })
      .end();
      return null;
    }
    return entity;
  };
}

function saveUpdates(updates) {
  return function(entity) {
    var updated = _.merge(entity, updates);
    return updated.saveAsync()
      .spread(updated => {
        return updated;
      });
  };
}

function removeEntity(res) {
  return function(entity) {
    if (entity) {
      return entity.removeAsync()
        .then(() => {
          res.status(204).end();
        });
    }
  };
}

function handleEntityNotFound(res) {
  return function(entity) {
    if (!entity) {
      res.status(404).end();
      return null;
    }
    return entity;
  };
}

function handleError(res, statusCode) {
  statusCode = statusCode || 500;
  return function(err) {
    res.status(statusCode).send(err);
  };
}

// Gets a list of StudyUsers
export function index(req, res) {
  var userStudy = req.user.study;
  StudyUsers.findAsync({ study: userStudy })
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets a single StudyUser from the DB
export function show(req, res) {
  var userStudy = req.user.study;
  StudyUsers.findOneAsync({ _id: req.params.id, study: userStudy })
    .then(handleEntityNotFound(res))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets a single StudyUser from the DB
// based on their 5 character unique identifier
export function check(req, res) {
  StudyUsers.findOneAsync({ userCode: req.params.userCode })
    .then(handleUserCodeNotFound(res))
    .then(respondWithFound(res))
    .catch(handleError(res));
}

// Creates a new StudyUsers in the DB
export function create(req, res) {
  var userStudy = req.user.study;
  
  // generate a random 5 character string to use as userCode
  var newUserCode = makeUserCode();

  // get a list of all the userCode's we have
  var userCodes = StudyUsers.findAsync().then(function(userCodesArray) {
    var i = 0;
    while(testUnique(newUserCode, userCodesArray)) {
      i++;
      if (i > 100) {
        return;
      }
      newUserCode = makeUserCode();
    }

    var newStudyUser = req.body;
    newStudyUser.userCode = newUserCode;
    newStudyUser.study = userStudy;

    StudyUsers.createAsync(newStudyUser)
      .then(respondWithResult(res, 201))
      .catch(handleError(res));

    });
}

function testUnique(newUserCode, userCodes) {
  for (var i = userCodes.length - 1; i >= 0; i--) {
    if(userCodes[i].userCode === newUserCode) {
      return true;
    }
  }
  return false;
}

// Updates an existing StudyUsers in the DB
export function update(req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  StudyUsers.findByIdAsync(req.params.id)
    .then(handleEntityNotFound(res))
    .then(saveUpdates(req.body))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Deletes a StudyUsers from the DB
export function destroy(req, res) {
  var userStudy = req.user.study;
  StudyUsers.findOneAsync({ _id: req.params.id, study: userStudy })
    .then(handleEntityNotFound(res))
    .then(removeEntity(res))
    .catch(handleError(res));
}

function makeUserCode()
{
    var text = "";
    var possible = "abcdefghjkmnpqrstuvwxyz0123456789";
    // because this code just needs to be random, not truly secure,
    // I've reduced the set of characters to be easy to read and enter

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}