'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var interventionDataCtrlStub = {
  index: 'interventionDataCtrl.index',
  show: 'interventionDataCtrl.show',
  create: 'interventionDataCtrl.create',
  update: 'interventionDataCtrl.update',
  destroy: 'interventionDataCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var interventionDataIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './interventionData.controller': interventionDataCtrlStub
});

describe('InterventionData API Router:', function() {

  it('should return an express router instance', function() {
    interventionDataIndex.should.equal(routerStub);
  });

  describe('GET /api/interventionData', function() {

    it('should route to interventionData.controller.index', function() {
      routerStub.get
        .withArgs('/', 'interventionDataCtrl.index')
        .should.have.been.calledOnce;
    });

  });

  describe('GET /api/interventionData/:id', function() {

    it('should route to interventionData.controller.show', function() {
      routerStub.get
        .withArgs('/:id', 'interventionDataCtrl.show')
        .should.have.been.calledOnce;
    });

  });

  describe('POST /api/interventionData', function() {

    it('should route to interventionData.controller.create', function() {
      routerStub.post
        .withArgs('/', 'interventionDataCtrl.create')
        .should.have.been.calledOnce;
    });

  });

  describe('PUT /api/interventionData/:id', function() {

    it('should route to interventionData.controller.update', function() {
      routerStub.put
        .withArgs('/:id', 'interventionDataCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('PATCH /api/interventionData/:id', function() {

    it('should route to interventionData.controller.update', function() {
      routerStub.patch
        .withArgs('/:id', 'interventionDataCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('DELETE /api/interventionData/:id', function() {

    it('should route to interventionData.controller.destroy', function() {
      routerStub.delete
        .withArgs('/:id', 'interventionDataCtrl.destroy')
        .should.have.been.calledOnce;
    });

  });

});
