'use strict';

/*

Table: InterventionData
Fields: UserID (String), Timestamp (Datetime), Level (Int) - Low, Medium or High

*/

var mongoose = require('bluebird').promisifyAll(require('mongoose'));

var InterventionDataSchema = new mongoose.Schema({
  userCode: String,
  timestamp: Date,
  interventionLevel: Number,//integer
  interventionActive: Boolean
});

export default mongoose.model('InterventionData', InterventionDataSchema);
