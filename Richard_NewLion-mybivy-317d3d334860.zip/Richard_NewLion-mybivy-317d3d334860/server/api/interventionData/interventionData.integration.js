'use strict';

var app = require('../..');
import request from 'supertest';

var newInterventionData;

describe('InterventionData API:', function() {

  describe('GET /api/interventionData', function() {
    var interventionDatas;

    beforeEach(function(done) {
      request(app)
        .get('/api/interventionData')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          interventionDatas = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      interventionDatas.should.be.instanceOf(Array);
    });

  });

  describe('POST /api/interventionData', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/interventionData')
        .send({
          name: 'New InterventionData',
          info: 'This is the brand new interventionData!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newInterventionData = res.body;
          done();
        });
    });

    it('should respond with the newly created interventionData', function() {
      newInterventionData.name.should.equal('New InterventionData');
      newInterventionData.info.should.equal('This is the brand new interventionData!!!');
    });

  });

  describe('GET /api/interventionData/:id', function() {
    var interventionData;

    beforeEach(function(done) {
      request(app)
        .get('/api/interventionData/' + newInterventionData._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          interventionData = res.body;
          done();
        });
    });

    afterEach(function() {
      interventionData = {};
    });

    it('should respond with the requested interventionData', function() {
      interventionData.name.should.equal('New InterventionData');
      interventionData.info.should.equal('This is the brand new interventionData!!!');
    });

  });

  describe('PUT /api/interventionData/:id', function() {
    var updatedInterventionData;

    beforeEach(function(done) {
      request(app)
        .put('/api/interventionData/' + newInterventionData._id)
        .send({
          name: 'Updated InterventionData',
          info: 'This is the updated interventionData!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedInterventionData = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedInterventionData = {};
    });

    it('should respond with the updated interventionData', function() {
      updatedInterventionData.name.should.equal('Updated InterventionData');
      updatedInterventionData.info.should.equal('This is the updated interventionData!!!');
    });

  });

  describe('DELETE /api/interventionData/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/interventionData/' + newInterventionData._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when interventionData does not exist', function(done) {
      request(app)
        .delete('/api/interventionData/' + newInterventionData._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
