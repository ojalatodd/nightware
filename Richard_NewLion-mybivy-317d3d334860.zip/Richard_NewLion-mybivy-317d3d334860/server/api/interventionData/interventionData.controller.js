/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/interventionData              ->  index
 * POST    /api/interventionData              ->  create
 * GET     /api/interventionData/:id          ->  show
 * PUT     /api/interventionData/:id          ->  update
 * DELETE  /api/interventionData/:id          ->  destroy
 */

'use strict';

import _ from 'lodash';
import InterventionData from './interventionData.model';

function respondWithResult(res, statusCode) {
  statusCode = statusCode || 200;
  return function(entity) {
    if (entity) {
      res.status(statusCode).json(entity);
    }
  };
}

function saveUpdates(updates) {
  return function(entity) {
    var updated = _.merge(entity, updates);
    return updated.saveAsync()
      .spread(updated => {
        return updated;
      });
  };
}

function removeEntity(res) {
  return function(entity) {
    if (entity) {
      return entity.removeAsync()
        .then(() => {
          res.status(204).end();
        });
    }
  };
}

function handleEntityNotFound(res) {
  return function(entity) {
    if (!entity) {
      res.status(404).end();
      return null;
    }
    return entity;
  };
}

function handleError(res, statusCode) {
  statusCode = statusCode || 500;
  return function(err) {
    res.status(statusCode).send(err);
  };
}

// Gets a list of InterventionDatas
export function index(req, res) {
  InterventionData.findAsync()
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets a single InterventionData from the DB
export function show(req, res) {
  InterventionData.findByIdAsync(req.params.id)
    .then(handleEntityNotFound(res))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets all InterventionData from the DB for a given user id
export function showByUser(req, res) {
  InterventionData.findAsync({ userID: req.params.userID })
    .then(handleEntityNotFound(res))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets all InterventionData from the DB for a given userCode within a date range
export function showUserByDateRange(req, res) {
  var startDate = new Date(0).setMilliseconds(req.params.startDate);
  var endDate = new Date(0).setMilliseconds(req.params.endDate);
  InterventionData.find({
    'timestamp': {
      '$gte': startDate,
      '$lte': endDate
    },
    'userCode': req.params.userCode
  })
    .sort('userCode')
    .sort('timestamp')
    .execAsync()
    .then(handleEntityNotFound(res))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Creates a new InterventionData in the DB
export function create(req, res) {
  InterventionData.createAsync(req.body)
    .then(respondWithResult(res, 201))
    .catch(handleError(res));
}

// Updates an existing InterventionData in the DB
export function update(req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  InterventionData.findByIdAsync(req.params.id)
    .then(handleEntityNotFound(res))
    .then(saveUpdates(req.body))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Deletes a InterventionData from the DB
export function destroy(req, res) {
  InterventionData.findByIdAsync(req.params.id)
    .then(handleEntityNotFound(res))
    .then(removeEntity(res))
    .catch(handleError(res));
}
