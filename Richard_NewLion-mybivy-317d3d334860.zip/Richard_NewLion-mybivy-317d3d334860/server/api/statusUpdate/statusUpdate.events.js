/**
 * StatusUpdate model events
 */

'use strict';

import {EventEmitter} from 'events';
var StatusUpdate = require('./statusUpdate.model');
var StatusUpdateEvents = new EventEmitter();

// Set max event listeners (0 == unlimited)
StatusUpdateEvents.setMaxListeners(0);

// Model events
var events = {
  'save': 'save'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  StatusUpdate.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function(doc) {
    StatusUpdateEvents.emit(event + ':' + doc._id, doc);
    StatusUpdateEvents.emit(event, doc);
  }
}

export default StatusUpdateEvents;
