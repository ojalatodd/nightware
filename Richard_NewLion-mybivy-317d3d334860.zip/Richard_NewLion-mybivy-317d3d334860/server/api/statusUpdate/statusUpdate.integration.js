'use strict';

var app = require('../..');
import request from 'supertest';

var newStatusUpdate;

describe('StatusUpdate API:', function() {

  describe('GET /api/statusUpdates', function() {
    var statusUpdates;

    beforeEach(function(done) {
      request(app)
        .get('/api/statusUpdates')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          statusUpdates = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      statusUpdates.should.be.instanceOf(Array);
    });

  });

  describe('POST /api/statusUpdates', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/statusUpdates')
        .send({
          name: 'New StatusUpdate',
          info: 'This is the brand new statusUpdate!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newStatusUpdate = res.body;
          done();
        });
    });

    it('should respond with the newly created statusUpdate', function() {
      newStatusUpdate.name.should.equal('New StatusUpdate');
      newStatusUpdate.info.should.equal('This is the brand new statusUpdate!!!');
    });

  });

  describe('GET /api/statusUpdates/:id', function() {
    var statusUpdate;

    beforeEach(function(done) {
      request(app)
        .get('/api/statusUpdates/' + newStatusUpdate._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          statusUpdate = res.body;
          done();
        });
    });

    afterEach(function() {
      statusUpdate = {};
    });

    it('should respond with the requested statusUpdate', function() {
      statusUpdate.name.should.equal('New StatusUpdate');
      statusUpdate.info.should.equal('This is the brand new statusUpdate!!!');
    });

  });

  describe('PUT /api/statusUpdates/:id', function() {
    var updatedStatusUpdate;

    beforeEach(function(done) {
      request(app)
        .put('/api/statusUpdates/' + newStatusUpdate._id)
        .send({
          name: 'Updated StatusUpdate',
          info: 'This is the updated statusUpdate!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedStatusUpdate = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedStatusUpdate = {};
    });

    it('should respond with the updated statusUpdate', function() {
      updatedStatusUpdate.name.should.equal('Updated StatusUpdate');
      updatedStatusUpdate.info.should.equal('This is the updated statusUpdate!!!');
    });

  });

  describe('DELETE /api/statusUpdates/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/statusUpdates/' + newStatusUpdate._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when statusUpdate does not exist', function(done) {
      request(app)
        .delete('/api/statusUpdates/' + newStatusUpdate._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
