/**
 * Using Rails-like standard naming convention for endpoints.
 * POST    /api/statusUpdates              ->  create
 * GET     /api/statusUpdates              ->  index
 */

'use strict';

import _ from 'lodash';
import StatusUpdate from './statusUpdate.model';
import StudyUsers from '../studyUsers/studyUsers.model';
import StressData from '../stressData/stressData.model';
import InterventionData from '../interventionData/interventionData.model';

// just used to start a session with the server
export function index(req, res) {
  respondWithEmpty(res, 200);
}

function respondWithResult(res, statusCode) {
  statusCode = statusCode || 200;
  return function(entity) {
    if (entity) {
      res.status(statusCode).json(entity);
    }
  };
}

function respondWithEmpty(res, statusCode) {
  statusCode = statusCode || 200;
  res.status(statusCode).end();
}

function saveUpdates(updates) {
  return function(entity) {
    var updated = _.merge(entity, updates);
    return updated.saveAsync()
      .spread(updated => {
        return updated;
      });
  };
}

function removeEntity(res) {
  return function(entity) {
    if (entity) {
      return entity.removeAsync()
        .then(() => {
          res.status(204).end();
        });
    }
  };
}

function handleEntityNotFound(res) {
  return function(entity) {
    if (!entity) {
      res.status(404).end();
      return null;
    }
    return entity;
  };
}

function handleError(res, statusCode) {
  statusCode = statusCode || 500;
  return function(err) {
    res.status(statusCode).send(err);
  };
}

// Creates a new StatusUpdate in the DB
export function create(req, res) {

  StudyUsers.findOneAsync({ userCode: req.body.userCode }).then(function(studyUser) {
    // look for a user with the provided userCode.  If they are found, and their
    // account is marked as active, proceed as normal

    if (studyUser && typeof studyUser !== 'undefined' && studyUser.active == true) {

      // parse out the stressData and interventionData entries
      // from the statusUpdate body.
      var stressData = {
        userCode: req.body.userCode,
        timestamp: req.body.timestamp,
        stressLevel: req.body.stressLevel,
        stressActive: req.body.stressActive,
      };

      var interventionData = {
        userCode: req.body.userCode,
        timestamp: req.body.timestamp,
        interventionLevel: req.body.interventionLevel,
        interventionActive: req.body.interventionActive,
      };

      // create the stressData and interventionData entries.
      StressData.createAsync(stressData)
        .then(respondWithResult(res, 201))
        .catch(handleError(res));

      InterventionData.createAsync(interventionData)
        .then(respondWithResult(res, 201))
        .catch(handleError(res));

    } else {
      // either failed to find a user, or the user was not marked as active
      res.status(403).json({
          "error":"The userCode provided did not match any active users in the database."
        });
    }
  });
}