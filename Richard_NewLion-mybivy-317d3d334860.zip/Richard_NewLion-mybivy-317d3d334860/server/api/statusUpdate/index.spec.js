'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var statusUpdateCtrlStub = {
  index: 'statusUpdateCtrl.index',
  show: 'statusUpdateCtrl.show',
  create: 'statusUpdateCtrl.create',
  update: 'statusUpdateCtrl.update',
  destroy: 'statusUpdateCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var statusUpdateIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './statusUpdate.controller': statusUpdateCtrlStub
});

describe('StatusUpdate API Router:', function() {

  it('should return an express router instance', function() {
    statusUpdateIndex.should.equal(routerStub);
  });

  describe('GET /api/statusUpdates', function() {

    it('should route to statusUpdate.controller.index', function() {
      routerStub.get
        .withArgs('/', 'statusUpdateCtrl.index')
        .should.have.been.calledOnce;
    });

  });

  describe('GET /api/statusUpdates/:id', function() {

    it('should route to statusUpdate.controller.show', function() {
      routerStub.get
        .withArgs('/:id', 'statusUpdateCtrl.show')
        .should.have.been.calledOnce;
    });

  });

  describe('POST /api/statusUpdates', function() {

    it('should route to statusUpdate.controller.create', function() {
      routerStub.post
        .withArgs('/', 'statusUpdateCtrl.create')
        .should.have.been.calledOnce;
    });

  });

  describe('PUT /api/statusUpdates/:id', function() {

    it('should route to statusUpdate.controller.update', function() {
      routerStub.put
        .withArgs('/:id', 'statusUpdateCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('PATCH /api/statusUpdates/:id', function() {

    it('should route to statusUpdate.controller.update', function() {
      routerStub.patch
        .withArgs('/:id', 'statusUpdateCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('DELETE /api/statusUpdates/:id', function() {

    it('should route to statusUpdate.controller.destroy', function() {
      routerStub.delete
        .withArgs('/:id', 'statusUpdateCtrl.destroy')
        .should.have.been.calledOnce;
    });

  });

});
