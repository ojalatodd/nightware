'use strict';

var customMongooseBase = require('mongoose')
require('mongoose-double')(customMongooseBase);

var mongoose = require('bluebird').promisifyAll(customMongooseBase);

var SchemaTypes = mongoose.Schema.Types;

var StatusUpdateSchema = new mongoose.Schema({
  userCode: String,
  timestamp: Date,
  stressLevel: SchemaTypes.Double,
  stressActive: Boolean,
  interventionLevel: Number,
  interventionActive: Boolean
});

export default mongoose.model('StatusUpdate', StatusUpdateSchema);
