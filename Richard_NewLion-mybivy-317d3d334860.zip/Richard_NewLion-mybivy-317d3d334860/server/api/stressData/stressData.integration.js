'use strict';

var app = require('../..');
import request from 'supertest';

var newStressData;

describe('StressData API:', function() {

  describe('GET /api/stressData', function() {
    var stressDatas;

    beforeEach(function(done) {
      request(app)
        .get('/api/stressData')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          stressDatas = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      stressDatas.should.be.instanceOf(Array);
    });

  });

  describe('POST /api/stressData', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/stressData')
        .send({
          name: 'New StressData',
          info: 'This is the brand new stressData!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newStressData = res.body;
          done();
        });
    });

    it('should respond with the newly created stressData', function() {
      newStressData.name.should.equal('New StressData');
      newStressData.info.should.equal('This is the brand new stressData!!!');
    });

  });

  describe('GET /api/stressData/:id', function() {
    var stressData;

    beforeEach(function(done) {
      request(app)
        .get('/api/stressData/' + newStressData._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          stressData = res.body;
          done();
        });
    });

    afterEach(function() {
      stressData = {};
    });

    it('should respond with the requested stressData', function() {
      stressData.name.should.equal('New StressData');
      stressData.info.should.equal('This is the brand new stressData!!!');
    });

  });

  describe('PUT /api/stressData/:id', function() {
    var updatedStressData;

    beforeEach(function(done) {
      request(app)
        .put('/api/stressData/' + newStressData._id)
        .send({
          name: 'Updated StressData',
          info: 'This is the updated stressData!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedStressData = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedStressData = {};
    });

    it('should respond with the updated stressData', function() {
      updatedStressData.name.should.equal('Updated StressData');
      updatedStressData.info.should.equal('This is the updated stressData!!!');
    });

  });

  describe('DELETE /api/stressData/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/stressData/' + newStressData._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when stressData does not exist', function(done) {
      request(app)
        .delete('/api/stressData/' + newStressData._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
