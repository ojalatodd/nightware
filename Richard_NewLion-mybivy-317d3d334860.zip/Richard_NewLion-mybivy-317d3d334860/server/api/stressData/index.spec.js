'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var stressDataCtrlStub = {
  index: 'stressDataCtrl.index',
  show: 'stressDataCtrl.show',
  create: 'stressDataCtrl.create',
  update: 'stressDataCtrl.update',
  destroy: 'stressDataCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var stressDataIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './stressData.controller': stressDataCtrlStub
});

describe('StressData API Router:', function() {

  it('should return an express router instance', function() {
    stressDataIndex.should.equal(routerStub);
  });

  describe('GET /api/stressData', function() {

    it('should route to stressData.controller.index', function() {
      routerStub.get
        .withArgs('/', 'stressDataCtrl.index')
        .should.have.been.calledOnce;
    });

  });

  describe('GET /api/stressData/:id', function() {

    it('should route to stressData.controller.show', function() {
      routerStub.get
        .withArgs('/:id', 'stressDataCtrl.show')
        .should.have.been.calledOnce;
    });

  });

  describe('POST /api/stressData', function() {

    it('should route to stressData.controller.create', function() {
      routerStub.post
        .withArgs('/', 'stressDataCtrl.create')
        .should.have.been.calledOnce;
    });

  });

  describe('PUT /api/stressData/:id', function() {

    it('should route to stressData.controller.update', function() {
      routerStub.put
        .withArgs('/:id', 'stressDataCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('PATCH /api/stressData/:id', function() {

    it('should route to stressData.controller.update', function() {
      routerStub.patch
        .withArgs('/:id', 'stressDataCtrl.update')
        .should.have.been.calledOnce;
    });

  });

  describe('DELETE /api/stressData/:id', function() {

    it('should route to stressData.controller.destroy', function() {
      routerStub.delete
        .withArgs('/:id', 'stressDataCtrl.destroy')
        .should.have.been.calledOnce;
    });

  });

});
