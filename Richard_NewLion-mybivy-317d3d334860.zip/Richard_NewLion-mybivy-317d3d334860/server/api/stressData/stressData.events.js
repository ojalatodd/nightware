/**
 * StressData model events
 */

'use strict';

import {EventEmitter} from 'events';
var StressData = require('./stressData.model');
var StressDataEvents = new EventEmitter();

// Set max event listeners (0 == unlimited)
StressDataEvents.setMaxListeners(0);

// Model events
var events = {
  'save': 'save',
  'remove': 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  StressData.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function(doc) {
    StressDataEvents.emit(event + ':' + doc._id, doc);
    StressDataEvents.emit(event, doc);
  }
}

export default StressDataEvents;
