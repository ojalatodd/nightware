'use strict';

/*

Table: StressData
Fields: UserID (String), Timestamp (Datetime), StressLevel (Float), Active (Bool)

*/

var customMongooseBase = require('mongoose')
require('mongoose-double')(customMongooseBase);
var mongoose = require('bluebird').promisifyAll(customMongooseBase);

var SchemaTypes = mongoose.Schema.Types;

var StressDataSchema = new mongoose.Schema({
  userCode: String,
  timestamp: Date,
  stressLevel: SchemaTypes.Double,
  stressActive: Boolean
});

export default mongoose.model('StressData', StressDataSchema);
