/**
 * Using Rails-like standard naming convention for endpoints.
 * GET     /api/stressData              ->  index
 * POST    /api/stressData              ->  create
 * GET     /api/stressData/:id          ->  show
 * PUT     /api/stressData/:id          ->  update
 * DELETE  /api/stressData/:id          ->  destroy
 */

'use strict';

import _ from 'lodash';
import StressData from './stressData.model';

function respondWithResult(res, statusCode) {
  statusCode = statusCode || 200;
  return function(entity) {
    if (entity) {
      res.status(statusCode).json(entity);
    }
  };
}

function saveUpdates(updates) {
  return function(entity) {
    var updated = _.merge(entity, updates);
    return updated.saveAsync()
      .spread(updated => {
        return updated;
      });
  };
}

function removeEntity(res) {
  return function(entity) {
    if (entity) {
      return entity.removeAsync()
        .then(() => {
          res.status(204).end();
        });
    }
  };
}

function handleEntityNotFound(res) {
  return function(entity) {
    if (!entity) {
      res.status(404).end();
      return null;
    }
    return entity;
  };
}

function handleError(res, statusCode) {
  statusCode = statusCode || 500;
  return function(err) {
    res.status(statusCode).send(err);
  };
}

// Gets a list of StressDatas
export function index(req, res) {
  StressData.findAsync()
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets a single StressData from the DB
export function show(req, res) {
  StressData.findByIdAsync(req.params.id)
    .then(handleEntityNotFound(res))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets all StressData from the DB for a given user id
export function showByUser(req, res) {
  StressData.findAsync({ userID: req.params.userID })
    .then(handleEntityNotFound(res))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Gets all StressData from the DB for a given userCode within a date range
export function showUserByDateRange(req, res) {
  var startDate = new Date(0).setMilliseconds(req.params.startDate);
  var endDate = new Date(0).setMilliseconds(req.params.endDate);
  StressData.find({
    'timestamp': {
      '$gte': startDate,
      '$lte': endDate
    },
    'userCode': req.params.userCode
  })
    .sort('userCode')
    .sort('timestamp')
    .execAsync()
    .then(handleEntityNotFound(res))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Creates a new StressData in the DB
export function create(req, res) {
  StressData.createAsync(req.body)
    .then(respondWithResult(res, 201))
    .catch(handleError(res));
}

// Updates an existing StressData in the DB
export function update(req, res) {
  if (req.body._id) {
    delete req.body._id;
  }
  StressData.findByIdAsync(req.params.id)
    .then(handleEntityNotFound(res))
    .then(saveUpdates(req.body))
    .then(respondWithResult(res))
    .catch(handleError(res));
}

// Deletes a StressData from the DB
export function destroy(req, res) {
  StressData.findByIdAsync(req.params.id)
    .then(handleEntityNotFound(res))
    .then(removeEntity(res))
    .catch(handleError(res));
}
