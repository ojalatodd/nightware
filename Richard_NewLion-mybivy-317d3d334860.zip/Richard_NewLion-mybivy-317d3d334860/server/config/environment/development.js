'use strict';

// Development specific configuration
// ==================================
module.exports = {

  ip:     process.env.OPENSHIFT_NODEJS_IP ||
          process.env.IP ||
          '127.0.0.1',

  // MongoDB connection options
  mongo: {
    uri: 'mongodb://dev_user:MeTesting13@ds053305.mlab.com:53305/my_bivy'
  },

  // Seed database on startup
  seedDB: false,

  secrets: {
    // session: 'mybivy-secret'
    session: 'iG7iz+qXlcVdcbusXSTAynpF8TUpXODadKJfphxiWjSmmVVwXGZTu3VYrfIxK0/YASTch1qEYCYun+AUi+D+ng'
  },

};
